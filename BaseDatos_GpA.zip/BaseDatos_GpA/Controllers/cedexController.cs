﻿using Microsoft.AspNetCore.Mvc;

namespace BaseDatos_GpA.Controllers
{
    public class cedexController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }     
    }
     
    public void llenarSexo()
    {
        List<SelectListItem> ListaSexo = new List<SelectListItem>();



        using (BaseDatos_GpAContext db = new BaseDatos_GpAContext())
        {
            ListaSexo = (from sexo in db.Sexos
                         where sexo.Bhabilitado == 1
                         select new SelectListItem
                         {
                             TextReader = sexo.Nombre,
                             ValueTask = sexo.Iidsexo.ToString()
                         }).ToList();
            ViewBag.ListaSexo = ListaSexo;
        }
    }
}
