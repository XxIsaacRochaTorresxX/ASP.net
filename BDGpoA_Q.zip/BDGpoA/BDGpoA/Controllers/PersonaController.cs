﻿using Microsoft.AspNetCore.Mvc;
using BDGpoA.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using BDGpoA.Clases;

namespace BDGpoA.Controllers
{
    public class PersonaController : Controller
    {
        public void LlenarSexo()
        {
            List<SelectListItem> listaSexo = new List<SelectListItem>();

            using (BDHospitalContext db = new BDHospitalContext())
            {
                listaSexo = (from sexo in db.Sexos
                             where sexo.Bhabilitado == 1
                             select new SelectListItem
                             {
                                 Text = sexo.Nombre,
                                 Value = sexo.Iidsexo.ToString()
                             }).ToList();
            }

            listaSexo.Insert(0, new SelectListItem { Text = "--Seleccione--", Value = "" });
            ViewBag.listaSexo = listaSexo;
        }
        public IActionResult Index(PersonaCLS oPersonaCLS)
        {
            List<PersonaCLS> listP = new List<PersonaCLS>();

            LlenarSexo();

            if(oPersonaCLS.iidsexo == 0 || oPersonaCLS.iidsexo==null)
            {
                using (BDHospitalContext db = new BDHospitalContext())
                {
                    listP = (from persona in db.Personas
                             join sexo in db.Sexos
                             on persona.Iidsexo equals sexo.Iidsexo
                             where persona.Bhabilitado == 1
                             select new PersonaCLS
                             {
                                 iidpersona = persona.Iidpersona,
                                 nombreCompleto = persona.Nombre + " " + persona.Appaterno + " " + persona.Apmaterno,
                                 email = persona.Email,
                                 nombreSexo = sexo.Nombre
                             }).ToList();
                }
            }
            else
            {
                using (BDHospitalContext db = new BDHospitalContext())
                {
                    listP = (from persona in db.Personas
                             join sexo in db.Sexos
                             on persona.Iidsexo equals sexo.Iidsexo
                             where persona.Bhabilitado == 1 && sexo.Iidsexo == oPersonaCLS.iidsexo
                             select new PersonaCLS
                             {
                                 iidpersona = persona.Iidpersona,
                                 nombreCompleto = persona.Nombre + " " + persona.Appaterno + " " + persona.Apmaterno,
                                 email = persona.Email,
                                 nombreSexo = sexo.Nombre
                             }).ToList();
                }
            }
            
            return View(listP);
        }

        public List<SelectListItem> LLanarSexo2()
        {
            List<SelectListItem> listaSexo = new List<SelectListItem>();

            using (BDHospitalContext db = new BDHospitalContext())
            {
                listaSexo = (from sexo in db.Sexos
                             where sexo.Bhabilitado == 1
                             select new SelectListItem
                             {
                                 Text = sexo.Nombre,
                                 Value = sexo.Iidsexo.ToString()
                             }).ToList();
                listaSexo.Insert(0, new SelectListItem { Text = "--Seleccione--", Value = "" });
            }

            return listaSexo;
        }

        public IActionResult Agregar()
        {
            ViewBag.listaSexo = LLanarSexo2();
            return View();

        }

        [HttpPost]
        public IActionResult Agregar(PersonaCLS oPersonaCLS)
        {
            ViewBag.listaSexo = LLanarSexo2();
            try
            {
                if (!ModelState.IsValid)
                {
                    //hay un problema
                    ViewBag.listaSexo = LLanarSexo2();
                    return View(oPersonaCLS);
                }
                else
                {
                    //agregar
                    using(BDHospitalContext db= new BDHospitalContext())
                    {
                        Persona oPersona = new Persona();
                        oPersona.Iidpersona = oPersonaCLS.iidpersona;
                        oPersona.Nombre = oPersonaCLS.nombreCompleto;
                        oPersona.Email= oPersonaCLS.email;
                        oPersona.Iidsexo = oPersonaCLS.iidsexo;
                        oPersona.Bhabilitado = 1;
                        db.Personas.Add(oPersona);
                        db.SaveChanges();
                    }
                }

            }
            catch (Exception ex)
            {
                ViewBag.listaSexo = LLanarSexo2();
                return View(oPersonaCLS);
            }
            return RedirectToAction("Index");
        }

    }
}
