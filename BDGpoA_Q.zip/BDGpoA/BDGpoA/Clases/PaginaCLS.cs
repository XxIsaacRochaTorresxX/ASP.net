﻿using System.ComponentModel.DataAnnotations;

namespace BDGpoA.Clases
{
    public class PaginaCLS
    {
        [Display(Name = "ID Pagina")]
        public int iidPagina { get; set; }
        [Display(Name = "Mensaje")]
        public string mensaje { get; set; }
        [Display(Name = "Accion")]
        public string accion { get; set; }
        [Display(Name = "Controller")]
        public string controller { get; set; }
    }
}
