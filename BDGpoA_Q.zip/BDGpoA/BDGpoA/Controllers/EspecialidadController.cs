﻿using Microsoft.AspNetCore.Mvc;
using BDGpoA.Models;
using BDGpoA.Clases;
using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;

namespace BDGpoA.Controllers
{

    public class EspecialidadController : Controller
    {
        public IActionResult Index(EspecialidadCLS oEspecialidadCLS)
        {            
            List<EspecialidadCLS> list = new List<EspecialidadCLS>();
            using (BDHospitalContext db = new BDHospitalContext())
            {
                if (oEspecialidadCLS.nombre == null || oEspecialidadCLS.nombre=="")
                {
                    list = (from especialidad in db.Especialidads
                            where especialidad.Bhabilitado == 1
                            select new EspecialidadCLS
                            {
                                idEspecialidad = especialidad.Iidespecialidad,
                                nombre = especialidad.Nombre,
                                descripcion = especialidad.Descripcion
                            }).ToList();
                    ViewBag.mensaje = "";
                }
                else
                {
                    list = (from especialidad in db.Especialidads
                            where especialidad.Bhabilitado == 1
                            && especialidad.Nombre.Contains(oEspecialidadCLS.nombre)
                            select new EspecialidadCLS
                            {
                                idEspecialidad = especialidad.Iidespecialidad,
                                nombre = especialidad.Nombre,
                                descripcion = especialidad.Descripcion
                            }).ToList();
                    ViewBag.mensaje = oEspecialidadCLS.nombre;
                }
            }
            return View(list);
        }

        public IActionResult Agregar()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Agregar(EspecialidadCLS oEspecialidad)
        {
            try
            {
                //conectamos BD
                using (BDHospitalContext db = new BDHospitalContext()) {
                    if (!ModelState.IsValid)
                    {
                        return View(oEspecialidad);
                    }
                    else
                    {
                        Especialidad objeto = new Especialidad();
                        objeto.Nombre = oEspecialidad.nombre;
                        objeto.Descripcion = oEspecialidad.descripcion;

                        objeto.Bhabilitado = 1;

                        db.Especialidads.Add(objeto);
                        db.SaveChanges();
                    }
                }
            } catch (Exception e)
            {
                return View(oEspecialidad);
            }

            return RedirectToAction("Index");
        }
    }

   
}
