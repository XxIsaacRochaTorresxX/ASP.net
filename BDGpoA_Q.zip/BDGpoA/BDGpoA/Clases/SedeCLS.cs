﻿using System.ComponentModel.DataAnnotations;

namespace BDGpoA.Clases
{
    public class SedeCLS
    {
        [Display(Name = "ID Sede")]
        public int iidsede { get; set; }

        [Display(Name = "Nombre Sede")]
        public string nombre { get; set; }

        [Display(Name = "Direccion")]
        public string direccion { get; set; }
    }
}
