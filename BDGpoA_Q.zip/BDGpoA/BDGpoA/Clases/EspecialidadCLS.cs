﻿using System.ComponentModel.DataAnnotations;

namespace BDGpoA.Clases
{
    public class EspecialidadCLS
    {
        [Display(Name= "ID Especialidad")]

        public int idEspecialidad { get; set; }


        [Display(Name = "Nombre Especialidad")]
        [Required(ErrorMessage ="Nombre de la especialidad es requerido")]
        public string nombre { get; set; }

        [Display(Name = "Descripción Especialidad")]
        [Required(ErrorMessage = "Descripción de la especialidad es requerida")]
        public string descripcion { get; set; }
    }
}
