﻿using System.ComponentModel.DataAnnotations;

namespace ExamenFinal.Clases
{
    public class PersonaCLS
    {
        [Display(Name = "IdPersona")]
     
        public int Id { get; set; }

     
        [Display(Name = "Nombre")]
        public string? Nombre { get; set; }

        [Display(Name = "Fecha")]
     
        public DateTime? Fecha { get; set; }

        [Display(Name = "Tipo")]

        public string? Tipo { get; set; }

 
    }
}
