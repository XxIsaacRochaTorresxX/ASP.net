﻿using Microsoft.AspNetCore.Mvc;
using BDGpoA.Models;
using BDGpoA.Clases;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BDGpoA.Controllers
{
    public class MedicamentoController : Controller
    {
        public List<SelectListItem> ListarFormaFarmaceutica()
        {
            List<SelectListItem> listaFormaFarmaceutica = new List<SelectListItem>();

            using (BDHospitalContext db = new BDHospitalContext())
            {
                listaFormaFarmaceutica = (from FormaFarmaceutica in db.FormaFarmaceuticas
                             where FormaFarmaceutica.Bhabilitado == 1
                             select new SelectListItem
                             {
                                 Text = FormaFarmaceutica.Nombre,
                                 Value = FormaFarmaceutica.Iidformafarmaceutica.ToString()
                             }).ToList();
            }

            listaFormaFarmaceutica.Insert(0, new SelectListItem { Text = "--Seleccione--", Value = "" });
            return listaFormaFarmaceutica;
        }
        
        public IActionResult Index(MedicamentoCLS oMedicamentoCLS)
        {
            List<MedicamentoCLS> medicamentoList = new List<MedicamentoCLS>();
            ViewBag.listaForma = ListarFormaFarmaceutica();
            using (BDHospitalContext db = new BDHospitalContext())
            {
                if (oMedicamentoCLS.iidFormaFarmaceutica == 0 || oMedicamentoCLS.iidFormaFarmaceutica == null)
                {
                    medicamentoList = (from medicamento in db.Medicamentos
                                       join formaFarmaceutica in db.FormaFarmaceuticas
                                       on medicamento.Iidformafarmaceutica equals formaFarmaceutica.Iidformafarmaceutica
                                       where medicamento.Bhabilitado == 1
                                       select new MedicamentoCLS
                                       {
                                           iidMedicamento = medicamento.Iidmedicamento,
                                           nombre = medicamento.Nombre,
                                           precio = (Decimal)medicamento.Precio,
                                           stock = (int)medicamento.Stock,
                                           nomFarmaceutica = formaFarmaceutica.Nombre,
                                           presentacion = medicamento.Presentacion
                                       }).ToList();
                }
                else
                {
                    medicamentoList = (from medicamento in db.Medicamentos
                                       join formaFarmaceutica in db.FormaFarmaceuticas
                                       on medicamento.Iidformafarmaceutica equals formaFarmaceutica.Iidformafarmaceutica
                                       where medicamento.Bhabilitado == 1 && medicamento.Iidformafarmaceutica == oMedicamentoCLS.iidFormaFarmaceutica
                                       select new MedicamentoCLS
                                       {
                                           iidMedicamento = medicamento.Iidmedicamento,
                                           nombre = medicamento.Nombre,
                                           precio = medicamento.Precio,
                                           stock = medicamento.Stock,
                                           nomFarmaceutica = formaFarmaceutica.Nombre,
                                           presentacion = medicamento.Presentacion
                                       }).ToList();
                }
            }
            return View(medicamentoList);
        }
    
        public IActionResult Agregar()
        {
            ViewBag.listaForma = ListarFormaFarmaceutica();
            return View();
        }

        [HttpPost]
        public IActionResult Agregar(MedicamentoCLS oMedicamentoCLS)
        {
            try
            {
                using (BDHospitalContext db = new BDHospitalContext())
                {
                    if (!ModelState.IsValid)
                    {
                        //Existe bronca
                        ViewBag.listaForma = ListarFormaFarmaceutica();
                        return View(oMedicamentoCLS);
                    }
                    else
                    {
                        Medicamento oMedicamento = new Medicamento();
                        oMedicamento.Nombre = oMedicamentoCLS.nombre;
                        oMedicamento.Concentracion = oMedicamentoCLS.concentracion;
                        oMedicamento.Iidformafarmaceutica = oMedicamentoCLS.iidFormaFarmaceutica;
                        oMedicamento.Precio = oMedicamentoCLS.precio;
                        oMedicamento.Stock = oMedicamentoCLS.stock;
                        oMedicamento.Presentacion = oMedicamentoCLS.presentacion;
                        oMedicamento.Bhabilitado = 1;
                        db.Add(oMedicamento);
                        db.SaveChanges();
                    }
                }
            } catch (Exception ex)
            {
                ViewBag.listaForma = ListarFormaFarmaceutica();
                return View(oMedicamentoCLS);
            }
            return RedirectToAction("Index");
        }
    }
}
