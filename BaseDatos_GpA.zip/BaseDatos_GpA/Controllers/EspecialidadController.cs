﻿using Microsoft.AspNetCore.Mvc;
using BaseDatos_GpA.Clases;
using BaseDatos_GpA.Models;

namespace BaseDatos_GpA.Controllers
{
    public class EspecialidadController : Controller
    {
        public IActionResult Index()
        {
            List<EspecialidadCLS> lista = new List<EspecialidadCLS>();
            using (BDHospitalContext db = new BDHospitalContext())
            {
                lista = (from especialidad in db.Especialidads
                         where especialidad.Bhabilitado == 1
                         select new EspecialidadCLS
                         {
                             idEspecialidad = especialidad.Iidespecialidad,
                             nombre = especialidad.Nombre,
                             descripcion = especialidad.Descripcion
                         }).ToList();

            }
            return View(lista);
        }
    }
}
