﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BaseDatos_GpA.Controllers
{
    public partial class ProcedimientoController : Controller
    {
        [Key]

        public int Iidmedicamento { get; set; }
        public string? Nombre { get; set; }
        public string? Concentracion { get; set; }
        public int? Iidformafarmaceutica { get; set; }
        public decimal? Precio { get; set; }
        public int? Stock { get; set; }
        public string? Presentacion { get; set; }
        public int? Bhabilitado { get; set; }

      
    }
}

