﻿using Microsoft.AspNetCore.Mvc;
using BDGpoA.Models;
using BDGpoA.Clases;

namespace BDGpoA.Controllers
{
    public class CitasController : Controller
    {
        public IActionResult Index()
        {
            /*List<CitasCLS> medicamentoList = new List<CitasCLS>();
            using (BDHospitalContext db = new BDHospitalContext())
            {
                medicamentoList = (from medicamento in db.Medicamentos
                                   join formaFarmaceutica in db.FormaFarmaceuticas
                                   on medicamento.Iidformafarmaceutica equals formaFarmaceutica.Iidformafarmaceutica
                                   where medicamento.Bhabilitado == 1
                                   select new CitasCLS
                                   {
                                       iidMedicamento = medicamento.Iidmedicamento,
                                       nombre = medicamento.Nombre,
                                       precio = medicamento.Precio + "",
                                       nomFarmaceutica = formaFarmaceutica.Nombre
                                   }).ToList();
            }*/
            return View(/*medicamentoList*/);
        }
    }
}
