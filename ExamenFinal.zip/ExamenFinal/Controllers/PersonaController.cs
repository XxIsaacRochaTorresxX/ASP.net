﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ExamenFinal.Clases;
using ExamenFinal.Models;

namespace ExamenFinal.Controllers
{
    public class PersonaController : Controller
    {
        // GET: PersonaController
        public ActionResult Index(PersonaCLS oPersonaCLS)
        {
            List<PersonaCLS> personaList = new List<PersonaCLS>(); //Creamos lista a partir de la clase usada
            using (ExamenContext db = new ExamenContext()) //conexión a base de datos
            {
                if (oPersonaCLS.Nombre == null || oPersonaCLS.Nombre == "")// aqui sacamos e imprimimos toda la lista
                {
                    personaList = (from persona in db.Personas
                                select new PersonaCLS
                                {
                                    Id = persona.Id,
                                    Nombre = persona.Nombre,
                                    Fecha = persona.Fecha,
                                    Tipo = persona.Tipo
                                }).ToList();//Así creamos la lista
                    ViewBag.Nombre = "";
                }
                else
                {
                    personaList = (from persona in db.Personas // este es el que hace la busqueda y te imprime
                                where persona.Nombre.Contains(oPersonaCLS.Nombre)
                                select new PersonaCLS
                                {
                                    Id = persona.Id,
                                    Nombre = persona.Nombre,
                                    Fecha = persona.Fecha,
                                    Tipo = persona.Tipo
                                }).ToList();
                    ViewBag.Nombre = oPersonaCLS.Nombre;
                }
            }
            return View(personaList);
        }

        [HttpPost]
        public IActionResult Eliminar(int Id)
        {
            string error = "";

            try
            {
                using (ExamenContext db = new ExamenContext())
                {
                    Persona oPersona = db.Personas
                                 .Where(p => p.Id == Id)// el primer elemento que encuentre con lo que le enviamos
                                 .First();//Primer elemnto que encuentre

                    //BORRADO LÓGICO//
                    // oSede.Bhabilitado = 0;
                    // db.SaveChanges();

                    //BORRADO FÍSICO//

                    db.Personas.Remove(oPersona);// eliminamos
                    db.SaveChanges();// guardamos cambios


                }

            }
            catch (Exception ex)
            {
                error = ex.Message;


            }

            return RedirectToAction("Index");// si sale bien nos redirige al index
        }

        public IActionResult Agregar()//Retornamos donde mismo para que se cargue la pagina y su contenido dentro de esta

        {
            return View();
        }



        [HttpPost]
        public IActionResult Guardar(PersonaCLS oPersonaCLS)
        {
            string nombreVista = "";
            try
            {
                if (oPersonaCLS.Id == 0) nombreVista = "Agregar";
                else nombreVista = "Editar";
                List<PersonaCLS> listaPersona = new List<PersonaCLS>();


                   // int idt = oPersonaCLS.Id;

                using (ExamenContext db = new ExamenContext())
                {
                    if (!ModelState.IsValid)
                    {
                        return View(nombreVista, oPersonaCLS);
                    }
                    else
                    {
                        if (oPersonaCLS.Id == 0)
                        {

                            Persona oPersona = new Persona();
                         
                            oPersona.Id = oPersonaCLS.Id;
                            oPersona.Nombre = oPersonaCLS.Nombre;
                            oPersona.Fecha = oPersonaCLS.Fecha;
                            oPersona.Tipo = oPersonaCLS.Tipo;

                            db.Personas.Add(oPersona);
                            db.SaveChanges();
                        }
                        else 
                        {
                            Persona persona = db.Personas.Where(p => p.Id == oPersonaCLS.Id).First();

                            persona.Id = oPersonaCLS.Id;
                            persona.Nombre = oPersonaCLS.Nombre;
                            persona.Fecha = oPersonaCLS.Fecha;
                            persona.Tipo = oPersonaCLS.Tipo;
                            db.SaveChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return View(nombreVista, oPersonaCLS);

            }

            return RedirectToAction("Index");
        }

        public IActionResult Editar(int id)
        {
            PersonaCLS oPersonaCLS = new PersonaCLS();
            using (ExamenContext db = new ExamenContext())
            {
                oPersonaCLS = (from Persona in db.Personas
                               where Persona.Id == id

                               select new PersonaCLS
                               {
                                   Id = Persona.Id,
                                   Nombre = Persona.Nombre,
                                   Fecha = Persona.Fecha,
                                   Tipo = Persona.Tipo
                               }).First();
            }


            return View(oPersonaCLS);
        }

    }
}
