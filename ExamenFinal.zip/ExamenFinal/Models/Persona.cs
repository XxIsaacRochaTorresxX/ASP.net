﻿using System;
using System.Collections.Generic;

namespace ExamenFinal.Models
{
    public partial class Persona
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public DateTime? Fecha { get; set; }
        public string? Tipo { get; set; }
        public int? Bhabilitado { get; set; }
    }
}
