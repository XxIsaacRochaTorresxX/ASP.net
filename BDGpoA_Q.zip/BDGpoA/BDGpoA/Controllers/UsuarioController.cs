﻿using Microsoft.AspNetCore.Mvc;
using BDGpoA.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using BDGpoA.Clases;

namespace BDGpoA.Controllers
{
    public class UsuarioController : Controller
    {
        public IActionResult Index(UsuarioCLS oUsuarioCLS)
        {
            List<UsuarioCLS> listaUsuario = new List<UsuarioCLS>();

            if (oUsuarioCLS.nombreUsuario == "" || oUsuarioCLS.nombreUsuario == null)
            {
                //muestra la lista completa
                using (BDHospitalContext db = new BDHospitalContext())
                {
                    listaUsuario = (from usuarios in db.Usuarios
                                    join TipoUsuario in db.TipoUsuarios
                                    on usuarios.Iidtipousuario equals TipoUsuario.Iidtipousuario
                                    join Persona in db.Personas
                                    on usuarios.Iidpersona equals Persona.Iidpersona
                                    where usuarios.Bhabilitado == 1
                                    select new UsuarioCLS
                                    {
                                        iidUsuario = usuarios.Iidusuario,
                                        nombreUsuario = usuarios.Nombreusuario,
                                        contraseña = usuarios.Contraseña,
                                        nombrepersona = Persona.Nombre + " " +
                                                        Persona.Appaterno + " " +
                                                        Persona.Apmaterno,
                                        tipoUsuario = TipoUsuario.Nombre
                                    }).ToList();
                }
            }
            else
            {
                using (BDHospitalContext db = new BDHospitalContext())
                {
                    listaUsuario = (from usuarios in db.Usuarios
                                    join TipoUsuario in db.TipoUsuarios
                                    on usuarios.Iidtipousuario equals TipoUsuario.Iidtipousuario
                                    join Persona in db.Personas
                                    on usuarios.Iidpersona equals Persona.Iidpersona
                                    where usuarios.Bhabilitado == 1
                                    &&
                                    usuarios.Nombreusuario.Contains(oUsuarioCLS.nombreUsuario)
                                    select new UsuarioCLS
                                    {
                                        iidUsuario = usuarios.Iidusuario,
                                        nombreUsuario = usuarios.Nombreusuario,
                                        contraseña = usuarios.Contraseña,
                                        nombrepersona = Persona.Nombre + " " +
                                                        Persona.Appaterno + " " +
                                                        Persona.Apmaterno,
                                        tipoUsuario = TipoUsuario.Nombre
                                    }).ToList();
                }
                ViewBag.NombreBuscar = oUsuarioCLS.nombreUsuario;
            }


            return View(listaUsuario);
        }

        //funcion que regrese la lista del tipo de usuario

        public List<SelectListItem> listarTipoUsuario()
        {
            List<SelectListItem> lista = new List<SelectListItem>();
            using (BDHospitalContext db = new BDHospitalContext())
            {
                lista = (from TipoUsuario in db.TipoUsuarios
                         where TipoUsuario.Bhabilitado == 1
                         select new SelectListItem
                         {
                             Text = TipoUsuario.Nombre.ToString(),
                             Value = TipoUsuario.Iidtipousuario.ToString()
                         }).ToList();
                lista.Insert(0, new SelectListItem { Text = "--Selecciona el Tipo de Usuario--", Value = "" });
            }
            return lista;
        }

        public List<SelectListItem> listarPersona()
        {
            List<SelectListItem> lista = new List<SelectListItem>();
            using (BDHospitalContext db = new BDHospitalContext())
            {
                lista = (from Persona in db.Personas
                         where Persona.Bhabilitado == 1
                         select new SelectListItem
                         {
                             Text = Persona.Nombre + " " +
                                    Persona.Appaterno + " " +
                                    Persona.Apmaterno,
                             Value = Persona.Iidpersona.ToString()
                         }).ToList();
                lista.Insert(0, new SelectListItem { Text = "--Selecciona la Persona--", Value = "" });
            }
            return lista;
        }
        public IActionResult Agregar()
        {
            ViewBag.listaTipoUsuario = listarTipoUsuario();
            ViewBag.listaPersona = listarPersona();
            return View();
        }


        [HttpPost]
        public IActionResult Agregar(UsuarioCLS oUsuarioCLS)
        {
            ViewBag.listaTipoUsuario = listarTipoUsuario();
            ViewBag.listaPersona = listarPersona();
            try
            {
                if (!ModelState.IsValid)
                {
                    //hay un problema
                    ViewBag.listaTipoUsuario = listarTipoUsuario();
                    ViewBag.listaPersona = listarPersona();
                    return View(oUsuarioCLS);
                }
                else
                {
                    //se realiza el alta del usuario

                    using (BDHospitalContext db = new BDHospitalContext())
                    {
                        Usuario oUsuario = new Usuario();
                        oUsuario.Iidpersona = oUsuarioCLS.iidPersona;
                        oUsuario.Nombreusuario = oUsuarioCLS.nombreUsuario;
                        oUsuario.Contraseña = oUsuarioCLS.contraseña;
                        oUsuario.Iidtipousuario = oUsuarioCLS.iidTipoUsuario;

                        oUsuario.Bhabilitado = 1;

                        db.Usuarios.Add(oUsuario);
                        db.SaveChanges();
                    }
                    
                }
            }
            catch (Exception ex)
            {
                ViewBag.listaTipoUsuario = listarTipoUsuario();
                ViewBag.listaPersona = listarPersona();
                return View(oUsuarioCLS);
            }
            return RedirectToAction("Index");
        }
    }
}