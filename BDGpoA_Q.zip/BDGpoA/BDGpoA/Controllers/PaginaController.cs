﻿using Microsoft.AspNetCore.Mvc;
using BDGpoA.Models;
using BDGpoA.Clases;

namespace BDGpoA.Controllers
{
    public class PaginaController : Controller
    {
        public IActionResult Index()
        {
            List<PaginaCLS> paginaList = new List<PaginaCLS>();
            using (BDHospitalContext db = new BDHospitalContext())
            {
                paginaList = (from pagina in db.Paginas
                            where pagina.Bhabilitado == 1
                            select new PaginaCLS
                            {
                                iidPagina = pagina.Iidpagina,
                                mensaje = pagina.Mensaje,
                                accion = pagina.Accion,
                                controller = pagina.Controlador

                            }).ToList();
            }
            return View(paginaList);
        }
    }
}
