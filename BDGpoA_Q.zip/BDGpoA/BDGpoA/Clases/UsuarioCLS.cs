﻿using System.ComponentModel.DataAnnotations;

namespace BDGpoA.Clases
{
    public class UsuarioCLS
    {
        [Display(Name = "ID USUARIO")]

        public int iidUsuario { get; set; }
        [Display(Name = "NOMBRE DE USUARIO")]

        public string? nombreUsuario { get; set; }

        [Display(Name = "CONTRASEÑA DEL USUARIO")]

        public string? contraseña { get; set; }
        [Display(Name = "NOMBRE PERSONA")]

        public string? nombrepersona { get; set; }

        [Display(Name = "TIPO DE USUARIO")]

        public string? tipoUsuario { get; set; }

        [Display(Name = "ID Tipo Usuario")]

        public int iidTipoUsuario { get; set; }

        [Display(Name = "ID PERSONA")]

        public int iidPersona { get; set; }

    }
}