﻿using System.ComponentModel.DataAnnotations;

namespace BDGpoA.Clases
{
    public class PersonaCLS
    {
        [Display(Name = "Id Persona")]
        public int iidpersona { get; set; }

        [Display(Name = "Nombre Completo")]
        [Required(ErrorMessage ="Se necesita nombre")]
        public string? nombreCompleto { get; set; }

        [Display(Name = "Correo Electronico")]
        [DataType(DataType.EmailAddress, ErrorMessage ="Se requiere un correo")]
        [EmailAddress]
        [Required(ErrorMessage = "Se necesita @")]
        public string? email { get; set; }

        [Display(Name = "Nombre Sexo")]
        [Required(ErrorMessage = "Se necesita sexo")]
        public string? nombreSexo { get; set; }

        [Display(Name = "id Sexo")]
        [Required(ErrorMessage = "Se necesita id setzo")]
        public int? iidsexo { get; set; }

    



    }
}
