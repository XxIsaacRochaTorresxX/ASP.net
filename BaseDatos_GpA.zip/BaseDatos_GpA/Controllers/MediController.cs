﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data;
using Microsoft.Data.SqlClient;
using BaseDatos_GpA.Models;


namespace BaseDatos_GpA.Controllers
{
    public class MediController : Controller
    {
        public IActionResult Index()
        {
            ViewData["msj"] = ListMTables();
            return View();
        }

        public static List<MedicTable> ListMTables()
        {

            List<MedicTable> listM = new List<MedicTable>();
            string connection = "Data Source=.\\SQLExpress;Initial Catalog=BDHospital;Integrated Security=True";
            using (SqlConnection _oSqlconn = new SqlConnection(connection)) 
            {
                using (SqlCommand _osqlCommand = new SqlCommand("MedicTable", _oSqlconn))
                {
                    _oSqlconn.Open();
                    _osqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                    SqlDataReader sdr = _osqlCommand.ExecuteReader();

                    while (sdr.Read()) 
                    {
                        MedicTable mtr = new MedicTable();

                        mtr.Nombre = sdr["Nombre"].ToString();
                        mtr.Concentracion = sdr["Concentracion"].ToString();
                        mtr.Presentacion = sdr["Presentacion"].ToString();
                        mtr.Precio = sdr["Precio"].ToString();

                        listM.Add(mtr);
                    }
                }

                return listM;
            }
        }
    }
}
