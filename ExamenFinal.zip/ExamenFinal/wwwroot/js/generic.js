﻿
function mostrarModal(titulo = "Deseas Guardar la informacion",
                    texto = "Esta acccion guarda la informacion en la BD!") {
    return Swal.fire({
        title:titulo,
        text:texto,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si!'
   
    })

}