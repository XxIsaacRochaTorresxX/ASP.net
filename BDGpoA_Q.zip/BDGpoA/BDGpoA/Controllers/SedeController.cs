﻿using Microsoft.AspNetCore.Mvc;
using BDGpoA.Models;
using BDGpoA.Clases;

namespace BDGpoA.Controllers
{
    public class SedeController : Controller
    {
        public IActionResult Index(SedeCLS oSedeCLS)
        {
            List<SedeCLS> sedeList = new List<SedeCLS>(); //Creamos lista a partir de la clase usada
            using (BDHospitalContext db = new BDHospitalContext()) //conexión a base de datos
            {
                if(oSedeCLS.nombre == null || oSedeCLS.nombre == "")// aqui sacamos e imprimimos toda la lista
                {
                    sedeList = (from sede in db.Sedes
                                where sede.Bhabilitado == 1
                                select new SedeCLS
                                {
                                    iidsede = sede.Iidsede,
                                    nombre = sede.Nombre,
                                    direccion = sede.Direccion
                                }).ToList();//Así creamos la lista
                    ViewBag.Nombre = "";
                }
                else
                {
                    sedeList = (from sede in db.Sedes // este es el que hace la busqueda y te imprime
                                where sede.Bhabilitado == 1 && sede.Nombre.Contains(oSedeCLS.nombre)
                                select new SedeCLS
                                {
                                    iidsede = sede.Iidsede,
                                    nombre = sede.Nombre,
                                    direccion = sede.Direccion
                                }).ToList();
                    ViewBag.Nombre = oSedeCLS.nombre;
                }
            }
            return View(sedeList);
        }

        [HttpPost]
        public IActionResult Eliminar(int iidsede)
        {
            string error = "";

            try
            {
                using (BDHospitalContext db = new BDHospitalContext() )
                {
                    Sede oSede = db.Sedes
                                 .Where(p => p.Iidsede == iidsede)// el primer elemento que encuentre con lo que le enviamos
                                 .First();//Primer elemnto que encuentre

                    //BORRADO LÓGICO//
                    // oSede.Bhabilitado = 0;
                    // db.SaveChanges();

                    //BORRADO FÍSICO//

                    db.Sedes.Remove(oSede);// eliminamos
                    db.SaveChanges();// guardamos cambios


                }

            } catch (Exception ex)
            {
                error = ex.Message;

                     
            }

            return RedirectToAction("Index");// si sale bien nos redirige al index
        }

        public IActionResult Agregar()//Retornamos donde mismo para que se cargue la pagina y su contenido dentro de esta

        {
            return View();
        }

        [HttpPost]
        public IActionResult Guardar(SedeCLS oSedeCLS)
        {
            string nombreVista = "";
            try
            {
                if (oSedeCLS.iidsede == 0) nombreVista = "Agregar";
                else nombreVista = "Editar";
                List<SedeCLS> listaSede = new List<SedeCLS>();

                using (BDHospitalContext db= new BDHospitalContext())
                {
                    if (!ModelState.IsValid)
                    {
                        return View(nombreVista, oSedeCLS);
                    }
                    else
                    {
                        // si el osedecls == 0 se da de alta nuevo registro
                        // si el osedecls != 0 se da de alta nuevo registro
                        if (oSedeCLS.iidsede == 0)
                        {

                            Sede oSede = new Sede();
                            oSede.Nombre = oSedeCLS.nombre;
                            oSede.Direccion = oSedeCLS.direccion;
                            oSede.Bhabilitado = 1;

                            db.Sedes.Add(oSede);
                            db.SaveChanges();
                        }
                        else
                        {
                            Sede sede = db.Sedes.Where(p => p.Iidsede == oSedeCLS.iidsede).First();
                            sede.Nombre = oSedeCLS.nombre;
                            sede.Direccion = oSedeCLS.direccion;
                            db.SaveChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return View(nombreVista, oSedeCLS);
                    
            }

            return RedirectToAction("Index");
        }

        public IActionResult Editar(int id)
        {
            SedeCLS oSedeCLS = new SedeCLS();
            using (BDHospitalContext db = new BDHospitalContext())
            { 
                oSedeCLS = (from Sede in db.Sedes
                           where Sede.Iidsede == id

                           select new SedeCLS
                           { 
                            iidsede = Sede.Iidsede,
                            nombre = Sede.Nombre,
                            direccion = Sede.Direccion
                           }).First();
            }


            return View(oSedeCLS);
        }


    }

    
}
