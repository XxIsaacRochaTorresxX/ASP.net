﻿using System.ComponentModel.DataAnnotations;

namespace BDGpoA.Clases
{
    public class CitasCLS
    {
        //Usuario
        [Display(Name = "NombreUsuario")]
        public string nombreUsuario { get; set; }
        [Display(Name = "Contraseña")]
        public string contrasenia { get; set; }

        //TipoUsuario
        [Display(Name = "NombreT")]
        public string nombreT { get; set; }
        [Display(Name = "DescripcionT")]
        public string descripcionT { get; set; }

        //EstadoCita
        [Display(Name = "VNombre")]
        public string vnombre { get; set; }
        [Display(Name = "VDescripcion")]
        public string vdescripcion { get; set; }

        //Cita
        [Display(Name = "Diagnostico")]
        public string diagnostico { get; set; }
        [Display(Name = "TotalPagar")]
        public double totalpagar { get; set; }

        //HistorialCita
        [Display(Name = "DFecha")]
        public string dfecha { get; set; }
        [Display(Name = "VObservacion")]
        public string vobservacion { get; set; }

        //Sede
        [Display(Name = "NombreS")]
        public string nombreS { get; set; }
        [Display(Name = "DireccionS")]
        public string direccionS { get; set; }

        //Medicamento
        [Display(Name = "NombreM")]
        public string nombreM { get; set; }
        [Display(Name = "ConcentracionM")]
        public string concentracionM { get; set; }

        //CitaMedicamento
        [Display(Name = "CantidadCM")]
        public string cantidadCM { get; set; }
        [Display(Name = "PrecioCM")]
        public double precioCM { get; set; }

    }
}
