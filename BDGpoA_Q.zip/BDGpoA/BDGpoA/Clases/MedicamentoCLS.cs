﻿using System.ComponentModel.DataAnnotations;

namespace BDGpoA.Clases
{
    public class MedicamentoCLS
    {
        [Display(Name = "ID Medicamento")]
        public int iidMedicamento { get; set; }

        [Display(Name = "Nombre Medicamento")]
        [Required(ErrorMessage = "Se requiere de un nombre del medicamento")]
        public string? nombre { get; set; }

        [Display(Name = "Precio")]
        [Required(ErrorMessage = "Se requiere de un precio del medicamento")]
        public Decimal? precio { get; set; }

        [Display(Name = "Stock")]
        [Required(ErrorMessage = "Se requiere de un stock del medicamento")]
        [Range(1,100, ErrorMessage ="Debe estar en el rango de 1 a 100")]
        public int? stock { get; set; }

        [Display(Name = "Presentacion")]
        public string? presentacion { get; set; }

        [Display(Name = "Concentracion")]
        public string? concentracion { get; set; }

        [Display(Name = "Nombre Farmaceutica")]
        public string? nomFarmaceutica { get; set; }
        [Display(Name = "identificador Farmaceutica")]

        public int? iidFormaFarmaceutica { get; set; }
    }
}
