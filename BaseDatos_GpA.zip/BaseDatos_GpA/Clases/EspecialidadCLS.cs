﻿namespace BaseDatos_GpA.Clases
{
    public class EspecialidadCLS
    {
        public int idEspecialidad{get;set;}
        public string nombre{get;set;}
        public string descripcion{ get; set; }

    }
}
