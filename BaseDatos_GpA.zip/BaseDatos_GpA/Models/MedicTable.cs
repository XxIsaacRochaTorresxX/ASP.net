﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BaseDatos_GpA.Models
{
    public class MedicTable
    {

        public string Nombre { get; set; } 
        public string Concentracion { get; set; } 

        public string Presentacion { get; set; }

        public string Precio { get; set; }

    }
}
